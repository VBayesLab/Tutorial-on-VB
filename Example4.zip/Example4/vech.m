function v = vech(A)
v = A(itril(size(A)));
end
